## CS231n Convolutional Neural Networks for Visual Recognition

斯坦福 cs231n 作业代码实践，代码实现主要参考了 [lightaime/cs231n](https://github.com/lightaime/cs231n)

- 教程笔记 [cs231n.github.io](http://cs231n.github.io/)
- 课程主页 [stanford cs231n](http://cs231n.stanford.edu/index.html)
- 进度安排 [course syllabus](http://cs231n.stanford.edu/syllabus.html)

上面的网页有时候不稳定，可能要 FQ 才能访问。

下载课程作业源代码:  [Assignment #1](http://cs231n.stanford.edu/assignments/2016/winter1516_assignment1.zip) & [Assignment #2](http://cs231n.stanford.edu/assignments/2016/winter1516_assignment2.zip) & [Assignment #3](http://cs231n.stanford.edu/assignments/2016/winter1516_assignment3.zip)

网上有很多的[资料](http://blog.csdn.net/zhangxb35/article/details/55223825)，包括中文翻译，课程视频等，但是个人觉得都不如写完作业代码的收获大。

我的 CSDN 博客笔记： [cs231n 课程作业](http://blog.csdn.net/zhangxb35/article/category/6727687)

---

注：我的这个是 2016 年做的作业，内容略旧，仅供参考。
